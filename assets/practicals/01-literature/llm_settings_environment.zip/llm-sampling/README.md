# LLM Sampling

A local playground for running a prompt over source text with a fresh conversation every time. Paste text on the left, write an instruction on the right, adjust the model settings below, and watch the response stream.

## Open the app

On Windows, double-click **Start LLM Sampling.cmd**. Python 3.10 or newer is required. The first launch creates a private `.venv` in this folder and installs the tokenizer library; it needs internet access once. Later launches run offline with your installed models. Keep the launcher window open while using the app; closing it stops the app.

For other platforms or manual setup:

```sh
python -m venv .venv
# Activate your virtual environment, then:
python -m pip install -r requirements.txt
python app.py --open
```

The app opens at `http://127.0.0.1:8765`. Use `python app.py --port 8766 --open` if that port is occupied by another program.

## Share the app

Run `python make-share-zip.py` to create `dist/llm-sampling-share.zip`, then send that ZIP. It contains the program, tests, and a **START HERE.txt** guide. It excludes virtual environments, caches, logs, model weights, and browser data. Rebuild the ZIP after changing the app so recipients receive the latest version.

Recipients extract the entire archive, install Python and Ollama if needed, download a compatible model with `ollama pull qwen2.5:3b`, and double-click **Start LLM Sampling.cmd** on Windows. Their first launch installs the tokenizer dependency. Everyone runs their own copy and local model; your `127.0.0.1` link cannot be used from their computers. macOS/Linux recipients use the manual setup above.

## Model interfaces

- **Ollama**, detected at port 11434. Supports the real BPE vocabularies and pretokenizers of standard Qwen 2/2.5/3/3.5 and Llama 3 models. It retrieves tokenizer data from `/api/show`; no Hugging Face account or tokenizer download is needed. Choose `qwen2.5:3b` for a relatively small starting model. If necessary, install it yourself with `ollama pull qwen2.5:3b`.
- **llama.cpp**, detected at port 8080. Uses the running server’s `/apply-template` and `/tokenize` endpoints and streams from `/completion`. A recent `llama-server` is required. Tokenizers that normalize input so that its characters cannot be aligned are rejected with a clear message. This adapter has automated fixture coverage; a live llama.cpp server was not available during development.

The Server address control accepts alternate **loopback HTTP ports**. Remote and cloud models are excluded. LM Studio and other OpenAI-compatible servers are not supported in this first version.

## Context and token colors

The rainbow shows actual model token boundaries, updated as you type. Gray input is excluded before sending a request. The app counts the **complete serialized prompt**, including model markers, section labels, and separator. It reserves one token for generation. The **Text → Prompt / Prompt → Text** switch moves the editor panes with a short animation and changes the actual order sent to the model. Reduced-motion preferences are respected. Input is discarded from the beginning of the first section, then from the beginning of the second section if necessary. Text first gives the instruction priority; prompt first lets the instruction be omitted before the source. Both orders retain model framing and section labels. Unicode characters that span several byte tokens are drawn once; hover information includes their contributing token IDs.

## Failure mode presets

The context window accepts **0** from either the number field or the slider. Zero excludes every source and instruction token (all appear gray). Below the cost of the normal prompt framing, only an empty-message startup wrapper is sent; the context panel and exact-input view show this explicitly. Ollama is given a viable engine capacity of at least 64 tokens, so the requested zero budget is an input cutoff and projected view, not a literal zero-sized model memory. With **Stop when full**, zero leaves no output space and finishes without calling the model.

The settings panel has four one-click presets. Each resets sampling settings to the standard baseline and applies its extreme values, while preserving your inputs, selected model, and input order. They change settings without starting a run. The selected preset is highlighted; manual changes update that highlight. **Reset defaults** restores standard sampling settings and keeps the chosen input order.

| Preset | Values | Experiment |
| --- | --- | --- |
| Tiny context | 64 context tokens | Watch early input disappear; switch to prompt first to omit instructions before source text. |
| High temperature | Temperature 2, Top P 1, Top K 0 | Broaden sampling to explore erratic or unrelated output. |
| Short output | 8 maximum output tokens | Observe incomplete sentences or answers. |
| High repeat penalty | Repeat penalty 4 | Explore distorted wording as the model avoids repeated tokens. |

These settings can encourage the described behavior; results vary with the model and prompt. Repeat penalty can be set manually up to 10.

## Generation and context capacity

Increasing maximum output does **not** reserve that entire amount in advance. Generation consumes free context as it proceeds. The live bar shows this, and tokens turn gray when they leave a **projected sliding window**. This is an educational projection, not model memory telemetry: Ollama does not expose its per-step retained token IDs. Engines may discard blocks, keep some tokens, stop, or use model-specific memory. Gray during generation therefore does not prove that a model has forgotten information, including information already incorporated into later tokens. This distinction is also shown in the app.

**Stop when full** limits the output to the space left after the sent input, rather than allowing context shifts. For Ollama, the context size is passed as `num_ctx`. With llama.cpp, context capacity is configured when the server starts: the app enforces its selected input cutoff and output limit, but cannot resize the server’s KV cache. Start `llama-server` with the desired `--ctx-size` when you want those sizes to match.

At completion, server input/output token counts are shown. A mismatch with the preview is explicitly reported. Streaming output counts come from token telemetry when available and are marked approximate otherwise. Final counts can include an end-of-sequence token.

Generated responses are also rainbow highlighted as they stream, with token IDs on hover. These boundaries are obtained by retokenizing the current response with the selected model’s tokenizer; they can differ from the engine’s original generated-token segmentation. The Rainbow tokens switch controls both the editors and output. Copy and Save run preserve the original response text without colors or markup.

Response tokens use the same **projected rolling context** as the input. Once generation exceeds the selected window, the oldest response tokens turn gray; the latest tokens stay rainbow colored. At context 0, every response token is gray. The entire response stays on screen and remains copyable. Completed responses keep the context and generation count from their own run when settings are edited for the next run. Engines may discard blocks or stop instead of sliding exactly one token at a time, so gray is a projection, not proof of forgotten model memory.

The app also checks the loaded engine’s context capacity. Some models enforce a minimum: the installed Qwen 3.5 runner used 2,048 tokens even when 512 was requested in live testing. A differing engine capacity is displayed in the context panel and run metrics. The selected budget still controls which input text the app sends and the educational projection.

## Fresh requests and data

Each run starts from only the current source, instruction, and model framing. No prior output, chat messages, or Ollama `context` array is sent. The Ollama adapter uses explicitly serialized raw prompts, so model-file conversations and default system instructions are not added. Thinking is disabled for Qwen thinking models. Model weights may stay loaded and servers may reuse matching prompt computation; this does not add past conversation content.

Pasted text and responses are kept in browser/server memory and are not written to files or browser storage automatically. Only model preferences and settings are saved locally. **Save run** explicitly downloads a JSON file containing source, prompt, settings, serialized input, output, and metrics. Local model servers have their own logging and retention settings.

The app binds only to `127.0.0.1`, accepts same-origin API calls, renders pasted/generated text without HTML interpretation, and never installs models automatically.

## Checks

```sh
python -m unittest discover -s tests -v
node --check web/app.js
node --test tests/context-view.test.mjs
```

The tests cover token budgeting, Unicode-safe cutoffs, instruction priority, fixed input framing, adapter requests, stream parsing, fresh-run isolation, validation, and cancellation. Live Ollama checks and browser checks should use a small output limit to keep model runs inexpensive.

API references: [Ollama generation](https://docs.ollama.com/api/generate), [Ollama request types](https://github.com/ollama/ollama/blob/main/api/types.go), [llama.cpp server](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md), [llama.cpp tokenizer definitions](https://github.com/ggml-org/llama.cpp/blob/master/src/llama-vocab.cpp).
