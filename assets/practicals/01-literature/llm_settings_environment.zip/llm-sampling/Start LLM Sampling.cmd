@echo off
setlocal
cd /d "%~dp0"
echo Starting LLM Sampling...
if not exist ".venv\Scripts\python.exe" (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3.10 or newer is required. Install it from https://www.python.org/downloads/ and try again.
    pause
    exit /b 1
  )
  python -m venv .venv
  if errorlevel 1 goto :failed
)
".venv\Scripts\python.exe" -c "import tokenizers; assert tokenizers.__version__ == '0.22.1'" >nul 2>nul
if errorlevel 1 (
  echo Setting up the tokenizer. The first launch needs an internet connection.
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 goto :failed
)
".venv\Scripts\python.exe" app.py --open
if errorlevel 1 goto :failed
exit /b 0
:failed
echo The app could not start. See the error above.
pause
exit /b 1
