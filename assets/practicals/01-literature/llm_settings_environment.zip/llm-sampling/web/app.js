import {responseTokenOutside} from './context-view.js';

const $ = (id) => document.getElementById(id);
const fields = ['num_ctx', 'num_predict', 'temperature', 'top_p', 'top_k', 'min_p', 'repeat_penalty', 'seed', 'context_behavior', 'input_order'];
const samplingFields = fields.filter(id => id !== 'input_order');
const stringFields = new Set(['context_behavior', 'input_order']);
const defaults = {num_ctx:4096, num_predict:512, temperature:0.7, top_p:0.9, top_k:40, min_p:0, repeat_penalty:1.1, seed:-1, context_behavior:'slide', input_order:'source_first'};
const presets = {
  'tiny-context': {values:{num_ctx:64}, note:'Tiny context: early input is excluded. Put the prompt first to watch its instructions disappear.'},
  'high-temperature': {values:{temperature:2, top_p:1, top_k:0}, note:'High temperature: broad sampling can produce tangents, contradictions, or nonsense. The effect varies by model.'},
  'short-output': {values:{num_predict:8}, note:'Short output: the response can stop mid-sentence when the eight-token limit is reached.'},
  'high-repeat': {values:{repeat_penalty:4}, note:'High repeat penalty: avoiding repeated tokens can distort wording, spelling, and meaning.'},
};
let orderAnimations = [];
const state = {online:false, preview:null, generated:0, active:false, runId:null, lastRun:null, previewVersion:0, previewAbort:null, timer:null, servers:[], preferences:{}};
const format = (n) => new Intl.NumberFormat('en-US').format(n || 0);

try { state.preferences = JSON.parse(localStorage.getItem('llm-sampling-settings') || '{}'); } catch { /* settings are optional */ }
for (const field of fields) $(field).value = state.preferences.settings?.[field] ?? defaults[field];
$('backend').value = state.preferences.backend || 'ollama';
$('url').value = state.preferences.url || 'http://127.0.0.1:11434';

function showError(message) {
  $('error').textContent = message || '';
  $('error').hidden = !message;
}

function settings() {
  return Object.fromEntries(fields.map(id => [id, stringFields.has(id) ? $(id).value : Number($(id).value)]));
}

function payload() {
  return {backend:$('backend').value, url:$('url').value.replace(/\/$/, ''), model:$('model').value,
    source:$('source').value, prompt:$('prompt').value, settings:settings()};
}

function persist() {
  try { localStorage.setItem('llm-sampling-settings', JSON.stringify({backend:$('backend').value, url:$('url').value,
    model:$('model').value, settings:settings()})); } catch { /* private browsing can disable storage */ }
}

async function api(path, body, signal) {
  const response = await fetch(path, body === undefined ? {signal} : {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body), signal,
  });
  const result = await response.json();
  if (!response.ok || result.error && result.online === undefined) throw new Error(result.error || `HTTP ${response.status}`);
  return result;
}

function syncSliders() {
  $('context-slider').value = Math.log2(Math.max(0, Number($('num_ctx').value)) + 1);
  $('temperature-slider').value = $('temperature').value;
}

function applyInputOrder(animate=false) {
  const cards = [$('source-card'), $('prompt-card')];
  const before = new Map(cards.map(card => [card, card.getBoundingClientRect()]));
  const focused = document.activeElement;
  const scrolls = ['source', 'prompt'].map(pane => [pane, $(pane).scrollTop]);
  orderAnimations.forEach(animation => animation.cancel());
  const promptFirst = $('input_order').value === 'prompt_first';
  const ordered = promptFirst ? [...cards].reverse() : cards;
  $('editors').append(...ordered);
  ordered.forEach((card, index) => card.querySelector('.number-tag').textContent = String(index + 1));
  $('swap-order').setAttribute('aria-pressed', String(promptFirst));
  $('swap-order').classList.toggle('prompt-first', promptFirst);
  $('swap-order').title = promptFirst ? 'Place the source text before the prompt' : 'Place the prompt before the source text';
  $('order-label').textContent = promptFirst ? 'Prompt → Text' : 'Text → Prompt';
  $('editors').setAttribute('aria-label', promptFirst ? 'Input workspace: prompt first, source text second' : 'Input workspace: source text first, prompt second');
  $('bar-source').style.order = promptFirst ? '2' : '1';
  $('bar-prompt').style.order = promptFirst ? '1' : '2';
  $('bar-output').style.order = '3';
  if (focused && cards.some(card => card.contains(focused))) focused.focus({preventScroll:true});
  for (const [pane, scroll] of scrolls) { $(pane).scrollTop = scroll; syncScroll(pane); }
  orderAnimations = [];
  if (animate && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    orderAnimations = cards.map(card => {
      const after = card.getBoundingClientRect(), first = before.get(card);
      return card.animate([
        {transform:`translate(${first.left - after.left}px, ${first.top - after.top}px)`, opacity:1},
        {opacity:0.82, offset:0.5},
        {transform:'translate(0, 0)', opacity:1},
      ], {duration:300, easing:'cubic-bezier(.22,.8,.3,1)'});
    });
  }
}

function presetValues(name) {
  return {...defaults, num_ctx:Math.min(defaults.num_ctx, Number($('num_ctx').max)), ...presets[name].values};
}

function updatePresetSelection() {
  const current = settings();
  let selected = null;
  for (const button of document.querySelectorAll('[data-preset]')) {
    const values = presetValues(button.dataset.preset);
    const active = samplingFields.every(id => current[id] === values[id]);
    button.setAttribute('aria-pressed', String(active));
    if (active) selected = button.dataset.preset;
  }
  $('preset-note').textContent = selected ? presets[selected].note : 'Choose a preset to experiment with an extreme setting.';
}

function applyPreset(name) {
  const values = presetValues(name);
  for (const field of samplingFields) $(field).value = values[field];
  syncSliders();
  schedulePreview(0);
}

function updateActions() {
  $('run').disabled = state.active || !state.online || !state.preview || !$('prompt').value.trim();
  $('stop').hidden = !state.active;
  for (const id of [...fields, 'context-slider', 'temperature-slider', 'backend', 'model', 'url',
    'refresh', 'connect', 'example', 'reset-settings', 'clear-source', 'clear-prompt', 'swap-order']) {
    $(id).disabled = state.active;
  }
  for (const button of document.querySelectorAll('[data-preset]')) button.disabled = state.active;
  $('source').readOnly = state.active;
  $('prompt').readOnly = state.active;
  $('copy-output').disabled = !$('output').textContent;
  $('download-output').disabled = !state.lastRun || state.active;
}

function clearHighlights() {
  for (const pane of ['source', 'prompt']) $(pane + '-stack').classList.remove('is-colored');
}

function schedulePreview(delay=180) {
  if (state.active) return;
  updatePresetSelection();
  clearTimeout(state.timer);
  state.previewVersion++;
  state.previewAbort?.abort();
  state.preview = null;
  state.generated = 0;
  $('engine-context').hidden = true;
  clearHighlights();
  updateActions();
  $('tokenizer').textContent = state.online ? 'Counting tokens…' : 'Waiting for tokenizer';
  state.timer = setTimeout(refreshPreview, delay);
}

async function refreshPreview() {
  if (!state.online || !$('model').value) return;
  const version = state.previewVersion;
  const controller = new AbortController();
  state.previewAbort = controller;
  try {
    const preview = await api('/api/preview', payload(), controller.signal);
    if (version !== state.previewVersion) return;
    state.preview = preview;
    $('num_ctx').max = preview.max_context;
    $('context-slider').max = Math.log2(preview.max_context + 1);
    $('context-limit').textContent = `Model capacity: ${format(preview.max_context)} tokens`;
    $('tokenizer').textContent = preview.tokenizer;
    showError('');
    renderEditors();
    renderBudget();
    persist();
  } catch (error) {
    if (error.name !== 'AbortError' && version === state.previewVersion) {
      showError(error.message);
      $('tokenizer').textContent = 'Tokenizer unavailable';
      $('budget-title').textContent = 'Token preview unavailable';
    }
  } finally { if (version === state.previewVersion) updateActions(); }
}

function makeTokenSpan(group, text, colorIndex) {
  const span = document.createElement('span');
  span.className = 'token';
  const hue = (colorIndex * 47 + 158) % 360;
  span.style.setProperty('--token-bg', `hsl(${hue} 65% 92%)`);
  span.style.setProperty('--token-ink', `hsl(${hue} 35% 29%)`);
  span.textContent = text;
  span.dataset.indices = JSON.stringify(group.map(token => token.index));
  span.dataset.ids = group.map(token => token.id).join(', ');
  return span;
}

function coloredText(text, tokens) {
  const chars = Array.from(text); // tokenizer offsets are Unicode code points, not UTF-16
  const fragment = document.createDocumentFragment();
  let index = 0, cursor = 0;
  while (index < tokens.length) {
    const first = tokens[index];
    if (first.end <= first.start) { index++; continue; }
    let end = first.end;
    const group = [first];
    const colorIndex = index;
    index++;
    // Some byte-level tokens share an emoji or other Unicode character. Show
    // that character once, with all contributing token IDs in the hover label.
    while (index < tokens.length && tokens[index].start < end) {
      end = Math.max(end, tokens[index].end);
      group.push(tokens[index++]);
    }
    if (first.start > cursor) fragment.append(document.createTextNode(chars.slice(cursor, first.start).join('')));
    fragment.append(makeTokenSpan(group, chars.slice(Math.max(cursor, first.start), end).join(''), colorIndex));
    cursor = end;
  }
  if (cursor < chars.length) fragment.append(document.createTextNode(chars.slice(cursor).join('')));
  return fragment;
}

function renderEditor(pane) {
  const preview = state.preview;
  const layer = $(pane + '-colors');
  const editor = $(pane);
  layer.replaceChildren();
  if (!preview || preview[pane + '_text'] !== editor.value) {
    $(pane + '-stack').classList.remove('is-colored');
    return;
  }
  const fragment = coloredText(editor.value, preview[pane]);
  if (editor.value.endsWith('\n')) fragment.append(document.createTextNode('\n'));
  layer.append(fragment);
  $(pane + '-stack').classList.toggle('is-colored', $('highlight').checked);
  syncScroll(pane);
}

function renderOutput(run=state.lastRun) {
  if (!run) return;
  for (const pane of ['output', 'thinking']) {
    const layer = $(pane);
    layer.classList.toggle('rainbow-output', $('highlight').checked);
    if (!$('highlight').checked || !run.token_view?.[pane]) {
      layer.textContent = run[pane];
      continue;
    }
    const previouslyColored = new Set(Array.from(layer.querySelectorAll('.token:not(.missing)'), span => span.dataset.indices));
    layer.replaceChildren(coloredText(run[pane], run.token_view[pane]));
    for (const span of layer.querySelectorAll('.token')) {
      const missing = responseTokenOutside(run, pane, JSON.parse(span.dataset.indices));
      span.classList.toggle('missing', missing);
      if (missing && state.active && previouslyColored.has(span.dataset.indices)) span.classList.add('newly-missing');
      span.title = `Response token ID${span.dataset.ids.includes(',') ? 's' : ''}: ${span.dataset.ids} · ` +
        (missing ? 'Outside projected context' : 'Included in projected context');
    }
  }
  $('output-token-note').hidden = !$('highlight').checked || !run.output;
  const missed = (run.token_view?.output || []).filter(token => responseTokenOutside(run, 'output', [token.index])).length;
  $('output-token-note').textContent = (missed ? `${format(missed)} response token${missed === 1 ? '' : 's'} outside this run’s projected window. ` : '') +
    'Rainbow = in the projected context; gray = outside it. Hover for token IDs. This is a projection, not engine memory telemetry.';
}

function syncScroll(pane) {
  const editor = $(pane), layer = $(pane + '-colors');
  layer.style.width = `${editor.clientWidth}px`;
  layer.style.paddingRight = '21px';
  layer.scrollTop = editor.scrollTop;
  layer.scrollLeft = editor.scrollLeft;
}

let visibilityPreview = null, visibilityThreshold = null;

function renderEditors() {
  renderEditor('source');
  renderEditor('prompt');
  visibilityPreview = null;
  updateTokenVisibility();
}

function threshold() {
  return Math.max(0, (state.preview?.input_tokens || 0) + state.generated - (state.preview?.context || 0));
}

function inContext(token) {
  return token.index !== null && token.index >= threshold();
}

function updateTokenVisibility() {
  if (!state.preview) return;
  const currentThreshold = threshold();
  if (visibilityPreview === state.preview && visibilityThreshold === currentThreshold) return;
  visibilityPreview = state.preview;
  visibilityThreshold = currentThreshold;
  for (const pane of ['source', 'prompt']) {
    const tokens = state.preview[pane];
    const missed = tokens.filter(token => !inContext(token)).length;
    $(pane + '-count').textContent = `${format(tokens.length)} token${tokens.length === 1 ? '' : 's'}`;
    $(pane + '-missed').textContent = missed ? `${format(missed)} ${state.generated ? 'outside view' : 'omitted'}` : '';
    for (const span of $(pane + '-colors').querySelectorAll('.token')) {
      const indices = JSON.parse(span.dataset.indices);
      const missing = indices.some(index => index === null || index < threshold());
      if (missing && !span.classList.contains('missing') && state.generated) span.classList.add('newly-missing');
      span.classList.toggle('missing', missing);
      span.title = `Token ID${indices.length > 1 ? 's' : ''}: ${span.dataset.ids} · ` +
        (indices.some(index => index === null) ? 'Not sent to the model' : missing ? 'Outside projected context' : 'Included in context view');
    }
  }
}

function renderBudget() {
  const preview = state.preview;
  if (!preview) return;
  const shifted = threshold();
  const source = preview.source.filter(inContext).length;
  const prompt = preview.prompt.filter(inContext).length;
  const occupied = Math.min(preview.context, preview.input_tokens + state.generated);
  const output = Math.min(preview.context, state.generated);
  const overhead = Math.max(0, occupied - source - prompt - output);
  const remaining = Math.max(0, preview.context - preview.input_tokens - state.generated);
  const missed = preview.source.length + preview.prompt.length - source - prompt;
  for (const [kind, count] of Object.entries({source,prompt,overhead,output})) {
    $('bar-' + kind).style.width = `${preview.context ? count / preview.context * 100 : 0}%`;
    $('budget-' + kind).textContent = format(kind === 'output' ? state.generated :
      kind === 'overhead' && preview.framing_only ? preview.overhead_tokens : count);
  }
  if (preview.context === 0) {
    $('budget-title').textContent = '0-token context · all pasted input omitted';
  } else if (state.generated && shifted) {
    $('budget-title').textContent = `${format(missed)} input tokens outside the projected window`;
  } else {
    $('budget-title').textContent = `${format(remaining)} token${remaining === 1 ? '' : 's'} remaining for context`;
  }
  $('budget-title').classList.toggle('warning', missed > 0 || remaining === 0);
  $('budget-missed').textContent = `${format(preview.omitted_tokens)} omitted` +
    (missed > preview.omitted_tokens ? ` · ${format(missed - preview.omitted_tokens)} projected out` : '');
  $('context-explainer').textContent = (preview.framing_only ? '' : preview.input_order === 'prompt_first' ?
    'Oldest prompt tokens are dropped first; the source text gets priority. ' :
    'Oldest source text is dropped first; the prompt gets priority. ') + preview.context_note;
  if (preview.engine_context && preview.engine_context !== preview.context) {
    $('context-explainer').textContent += ` The engine reports a ${format(preview.engine_context)}-token capacity. The selected ${format(preview.context)}-token budget controls the input cutoff and the projection.`;
  }
  $('compiled-prompt').textContent = preview.compiled_prompt;
  $('run-hint').textContent = preview.framing_only ? 'No pasted input will be sent; the model will generate from its startup markers only.' :
    preview.prompt_cut > 0 ? 'Part of your prompt is omitted. Increase the context window to include it.' :
    preview.omitted_tokens ? `${format(preview.omitted_tokens)} tokens will be excluded from this run.` : 'Your next run starts with an empty conversation.';
  updateTokenVisibility();
}

function showConnection(server) {
  state.online = server.online;
  $('connection-dot').className = `status-dot ${server.online ? 'online' : 'offline'}`;
  const name = server.kind === 'ollama' ? 'Ollama' : 'llama.cpp';
  $('connection-status').textContent = server.online ? `${name} connected` : `${name} is not running`;
  $('connection-detail').textContent = server.online ? `${server.models.length} local model${server.models.length === 1 ? '' : 's'} available · ${server.url}` : server.url;
  const previous = $('model').value || state.preferences.model;
  $('model').replaceChildren();
  for (const model of server.models) {
    const option = document.createElement('option');
    option.value = model.name;
    option.textContent = model.name;
    $('model').append(option);
  }
  if (server.models.some(model => model.name === previous)) $('model').value = previous;
  else if (server.models.some(model => model.name === 'qwen2.5:3b')) $('model').value = 'qwen2.5:3b';
  if (!server.models.length) {
    const option = document.createElement('option');
    option.value = '';
    option.textContent = server.online ? 'No local models installed' : 'No connection';
    $('model').append(option);
  }
  $('setup').replaceChildren();
  $('setup').hidden = server.online && server.models.length > 0;
  if (!server.online && server.kind === 'ollama') {
    $('setup').append('Open Ollama, or install it from ');
    const link = document.createElement('a');
    link.href = 'https://ollama.com/download'; link.target = '_blank'; link.rel = 'noreferrer'; link.textContent = 'ollama.com';
    $('setup').append(link, '. Then refresh the connection.');
    const start = document.createElement('button'); start.className = 'button secondary'; start.textContent = 'Start installed Ollama';
    start.addEventListener('click', async () => {
      start.disabled = true;
      try { await api('/api/start-ollama', {}); await new Promise(resolve => setTimeout(resolve, 1000)); await connect(); }
      catch (error) { showError(error.message); start.disabled = false; }
    });
    $('setup').append(start);
  } else if (server.online && !server.models.length) {
    $('setup').append('Install a model in your model interface. For Ollama, open a terminal and run ');
    const code = document.createElement('code'); code.textContent = 'ollama pull qwen2.5:3b';
    $('setup').append(code, ', then refresh.');
  } else if (!server.online) {
    $('setup').textContent = 'Start llama-server with a model, then enter its local address. The server needs /props, /apply-template, /tokenize, and /completion endpoints.';
  }
  schedulePreview(0);
}

async function connect() {
  document.body.classList.add('busy');
  showError('');
  state.online = false;
  state.preview = null;
  updateActions();
  try {
    const result = await api('/api/connect', {backend:$('backend').value, url:$('url').value});
    showConnection(result);
  } catch (error) { showError(error.message); }
  finally { document.body.classList.remove('busy'); }
}

async function initialize() {
  syncSliders();
  try {
    const result = await api('/api/discover');
    state.servers = result.servers;
    const preferred = result.servers.find(server => server.kind === $('backend').value);
    if (state.preferences.url && state.preferences.url !== preferred?.url) { await connect(); return; }
    const server = preferred?.online ? preferred : result.servers.find(server => server.online) || preferred;
    if (server) { $('backend').value = server.kind; $('url').value = server.url; showConnection(server); }
  } catch (error) { showError(`Cannot reach the app server: ${error.message}`); }
}

function handleStreamEvent(event, run) {
  if (event.type === 'status') {
    $('run-status').textContent = 'Preparing';
    $('run-result').textContent = event.text;
  } else if (event.type === 'start') {
    run.preview = event.preview;
    state.preview = event.preview;
    $('tokenizer').textContent = event.preview.tokenizer;
    $('run-status').textContent = 'Generating';
    $('run-result').textContent = 'Loading the model and evaluating input…';
    renderEditors(); renderBudget();
  } else if (event.type === 'capacity') {
    if (run.preview) run.preview.engine_context = event.engine_context;
    $('engine-context').hidden = event.engine_context === state.preview?.context;
    $('engine-context').textContent = `Engine: ${format(event.engine_context)} tokens`;
    renderBudget();
  } else if (event.type === 'chunk') {
    run.output += event.text || '';
    run.thinking += event.thinking || '';
    run.generated = event.generated;
    state.generated = event.generated;
    if (event.token_view) run.token_view = event.token_view;
    $('output-empty').hidden = true;
    $('output').hidden = false;
    renderOutput(run);
    $('thinking-details').hidden = !run.thinking;
    $('run-result').textContent = '';
    $('output-stats').textContent = `${event.count_exact ? '' : '≈ '}${format(event.generated)} tokens`;
    renderBudget();
    updateActions();
  } else if (event.type === 'done') {
    run.metrics = event;
    run.finished = true;
    run.generated = event.generated;
    if (event.token_view) run.token_view = event.token_view;
    renderOutput(run);
    state.generated = event.generated;
    $('run-status').textContent = event.reason === 'stopped' ? 'Stopped' : event.reason === 'length' || event.reason === 'limit' ? 'Limit reached' : 'Complete';
    $('output-stats').textContent = `${format(event.generated)} tokens` + (event.tokens_per_second ? ` · ${event.tokens_per_second} tok/s` : '');
    let result = event.reason === 'stopped' ? 'Run stopped. Partial output is kept.' :
      `Fresh run complete${event.elapsed ? ` in ${event.elapsed.toFixed(1)}s` : ''}.`;
    if (event.actual_input !== null && event.actual_input !== undefined) {
      result += ` Server reports ${format(event.actual_input)} input tokens and ${format(event.generated)} generated tokens.`;
      if (event.actual_input !== event.planned_input) result += ` Preview counted ${format(event.planned_input)} input tokens; the server count differs. The token view is not verified for this run.`;
    }
    if (event.engine_context && event.engine_context !== run.config.settings.num_ctx) {
      result += ` Requested context: ${format(run.config.settings.num_ctx)}; engine capacity: ${format(event.engine_context)}.`;
    }
    $('run-result').textContent = result;
    if (!run.output && !run.thinking) { $('output-empty').hidden = false; }
    renderBudget();
  } else if (event.type === 'error') {
    run.error = event.error;
    showError(event.error);
    $('run-status').textContent = 'Error';
    $('run-result').textContent = 'The partial response is kept. Adjust the settings or connection and try again.';
  }
}

async function generate() {
  if ($('run').disabled || state.active) return;
  clearTimeout(state.timer);
  state.previewAbort?.abort();
  state.previewVersion++;
  const config = payload();
  const run = {id:crypto.randomUUID(), started_at:new Date().toISOString(), config, output:'', thinking:'', preview:null, metrics:null};
  state.lastRun = run;
  state.runId = run.id;
  state.active = true;
  state.generated = 0;
  $('engine-context').hidden = true;
  showError('');
  $('output').textContent = '';
  $('output-token-note').hidden = true;
  $('output').hidden = true;
  $('output').classList.add('streaming');
  $('thinking').textContent = '';
  $('thinking-details').hidden = true;
  $('output-empty').hidden = false;
  $('output-stats').textContent = '';
  $('run-status').textContent = 'Preparing';
  $('run-result').textContent = 'Starting a fresh request…';
  $('stop').disabled = false;
  $('stop').textContent = '■ Stop';
  updateActions();
  renderBudget();
  try {
    const response = await fetch('/api/generate', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...config, run_id:run.id})});
    if (!response.ok) { const result = await response.json(); throw new Error(result.error || `HTTP ${response.status}`); }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const {value, done} = await reader.read();
      buffer += decoder.decode(value || new Uint8Array(), {stream:!done});
      let newline;
      while ((newline = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, newline); buffer = buffer.slice(newline + 1);
        if (line.trim()) handleStreamEvent(JSON.parse(line), run);
      }
      if (done) { if (buffer.trim()) handleStreamEvent(JSON.parse(buffer), run); break; }
    }
    if (!run.finished && !run.error) throw new Error('The app connection closed before the run finished.');
  } catch (error) {
    run.error = error.message;
    showError(error.message);
    $('run-status').textContent = 'Error';
    // Also stop the upstream model if the browser reader fails.
    api('/api/cancel', {run_id:run.id}).catch(() => {});
  } finally {
    state.active = false;
    state.runId = null;
    $('output').classList.remove('streaming');
    updateActions();
  }
}

$('run').addEventListener('click', generate);
$('swap-order').addEventListener('click', () => {
  $('input_order').value = $('input_order').value === 'prompt_first' ? 'source_first' : 'prompt_first';
  applyInputOrder(true);
  schedulePreview(0);
});
for (const button of document.querySelectorAll('[data-preset]')) {
  button.addEventListener('click', () => applyPreset(button.dataset.preset));
}
$('stop').addEventListener('click', async () => {
  $('stop').disabled = true;
  $('stop').textContent = 'Stopping…';
  try { await api('/api/cancel', {run_id:state.runId}); }
  catch (error) { showError(error.message); $('stop').disabled = false; $('stop').textContent = '■ Stop'; }
});
$('refresh').addEventListener('click', connect);
$('connect').addEventListener('click', connect);
$('backend').addEventListener('change', () => {
  $('url').value = $('backend').value === 'ollama' ? 'http://127.0.0.1:11434' : 'http://127.0.0.1:8080';
  state.preferences.model = null;
  connect();
});
$('url').addEventListener('input', () => { state.online = false; state.preview = null; updateActions(); });
$('model').addEventListener('change', () => schedulePreview(0));
for (const pane of ['source', 'prompt']) {
  $(pane).addEventListener('input', () => schedulePreview());
  $(pane).addEventListener('scroll', () => syncScroll(pane));
  let hoverFrame = null;
  $(pane).addEventListener('mousemove', event => {
    if (hoverFrame !== null || !$('highlight').checked) return;
    const {clientX, clientY} = event;
    hoverFrame = requestAnimationFrame(() => {
      hoverFrame = null;
      const span = Array.from($(pane + '-colors').querySelectorAll('.token')).find(token =>
        Array.from(token.getClientRects()).some(rect => clientX >= rect.left && clientX <= rect.right && clientY >= rect.top && clientY <= rect.bottom));
      $(pane).title = span?.title || '';
    });
  });
  $('clear-' + pane).addEventListener('click', () => { $(pane).value = ''; schedulePreview(0); $(pane).focus(); });
}
for (const field of fields) $(field).addEventListener('input', () => { syncSliders(); schedulePreview(); });
$('context-slider').addEventListener('input', () => {
  const value = Math.max(0, 2 ** Number($('context-slider').value) - 1);
  $('num_ctx').value = Math.min(Number($('num_ctx').max), value < 64 ? Math.round(value) : Math.round(value / 64) * 64);
  schedulePreview(80);
});
$('temperature-slider').addEventListener('input', () => { $('temperature').value = $('temperature-slider').value; schedulePreview(80); });
$('reset-settings').addEventListener('click', () => { for (const field of samplingFields) $(field).value = field === 'num_ctx' ? Math.min(defaults.num_ctx, Number($('num_ctx').max)) : defaults[field]; syncSliders(); schedulePreview(0); });
$('highlight').addEventListener('change', () => { renderEditors(); renderOutput(); });
$('example').addEventListener('click', () => {
  $('source').value = 'The observatory opens just before sunrise. Its solar panels collect energy during the day, while a battery keeps the telescopes running at night.\n\nLast winter, the team replaced the oldest battery. Power outages fell from twelve per month to just one. Scientists can now plan longer observations without interruption.\n\nThe next project is a small weather station. It will measure cloud cover, humidity, and wind speed so the team can choose the clearest nights for their work.';
  $('prompt').value = 'Summarize the source text in three short bullet points. Use only information in the text.';
  schedulePreview(0);
});
$('copy-output').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('output').textContent); $('copy-output').textContent = 'Copied'; setTimeout(() => $('copy-output').textContent = 'Copy', 1500); }
  catch { showError('Copy failed. Select the response text and copy it manually.'); }
});
$('download-output').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(state.lastRun, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob), link = document.createElement('a');
  link.href = url; link.download = `llm-sampling-${state.lastRun.started_at.replace(/[:.]/g, '-')}.json`;
  link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
});
document.addEventListener('keydown', event => {
  if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); generate(); }
  if (event.key === 'Escape' && state.active && !$('stop').disabled) $('stop').click();
});
window.addEventListener('resize', () => { syncScroll('source'); syncScroll('prompt'); });
window.addEventListener('pagehide', () => {
  if (state.runId) navigator.sendBeacon('/api/cancel', new Blob([JSON.stringify({run_id:state.runId})], {type:'application/json'}));
});
applyInputOrder();
updatePresetSelection();
initialize();
