// The response follows the input in the projected rolling window. Once the
// generated token count exceeds the entire window, early response tokens leave.
// This uses the run's own settings so edits for the next run cannot recolor it.
export function responseTokenOutside(run, pane, indices) {
  const context = run.preview?.context ?? run.config.settings.num_ctx;
  if (context === 0) return true;
  const generated = run.generated ?? run.metrics?.generated ?? 0;
  const firstRetained = Math.max(0, generated - context);
  const offset = pane === 'output' ? (run.token_view?.thinking?.length || 0) : 0;
  return indices.some(index => index === null || index + offset < firstRetained);
}
