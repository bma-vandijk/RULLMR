"""Opt-in live checks: python tests/live_smoke.py (requires running app + Ollama)."""
import http.client
import json
import time
import uuid


def send(body):
    conn = http.client.HTTPConnection('127.0.0.1',8765,timeout=180)
    conn.request('POST','/api/generate',json.dumps(body),{'Content-Type':'application/json'})
    response = conn.getresponse()
    assert response.status == 200, response.read()
    return conn, response


def config(model, source, prompt, ctx=512, output=8):
    return {'backend':'ollama', 'url':'http://127.0.0.1:11434', 'model':model,
            'source':source, 'prompt':prompt, 'settings':{'num_ctx':ctx,'num_predict':output,
            'temperature':0,'seed':42}, 'run_id':str(uuid.uuid4())}


def run(body):
    conn, response = send(body)
    events = [json.loads(line) for line in response]
    conn.close()
    errors = [e for e in events if e['type'] == 'error']
    assert not errors, errors
    start = next(e for e in events if e['type'] == 'start')
    end = next(e for e in events if e['type'] == 'done')
    assert end['actual_input'] == start['preview']['input_tokens'], (start['preview']['input_tokens'], end)
    assert end['generated'] <= body['settings']['num_predict']
    print(json.dumps({'model':body['model'], 'context':body['settings']['num_ctx'],
                      'input_tokens':end['actual_input'], 'omitted':start['preview']['omitted_tokens'],
                      'output':''.join(e.get('text','') for e in events if e['type']=='chunk'), 'metrics':end}))


if __name__ == '__main__':
    run(config('qwen2.5:3b','The new battery reduced outages from twelve per month to one.',
               'How many outages occur each month now? Answer in one word.'))
    run(config('qwen2.5:3b','café, 🧑🏽‍🔬, 漢字, e\u0301. '*40,'Name the first place in the text.',64,4))
    run(config('qwen3.5:4b','A café sells tea for two euros.','What does the café sell? Answer in one word.',512,8))

    body = config('qwen2.5:3b','A small observatory.','Write a long story about the observatory.',512,500)
    conn, response = send(body)
    while True:
        event = json.loads(response.readline())
        if event['type'] == 'error': raise AssertionError(event)
        if event['type'] == 'start': break
    cancel = http.client.HTTPConnection('127.0.0.1',8765,timeout=5)
    cancelled_at = time.monotonic()
    cancel.request('POST','/api/cancel',json.dumps({'run_id':body['run_id']}),{'Content-Type':'application/json'})
    assert json.loads(cancel.getresponse().read())['stopped']
    cancel.close()
    remaining = [json.loads(line) for line in response]
    conn.close()
    assert any(e['type'] == 'done' and e['reason'] == 'stopped' for e in remaining), remaining
    assert time.monotonic() - cancelled_at < 5, 'Cancellation took longer than five seconds'
    print('Cancellation: passed')
