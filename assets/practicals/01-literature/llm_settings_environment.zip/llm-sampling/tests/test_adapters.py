import http.client
import json
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

from sampling.backends import OllamaModel, LlamaCppModel
from sampling.tokenization import LocalTokenizer, ServerTokenizer
from sampling.transport import Job, ModelError, stream_json, validate_url


class AdapterTests(unittest.TestCase):
    def test_ollama_raw_requests_contain_no_history(self):
        model = OllamaModel.__new__(OllamaModel)
        model.url, model.model, model.stop = 'http://127.0.0.1:11434', 'qwen2.5:3b', ['<|im_end|>']
        settings = {'temperature':0.7, 'top_p':0.9, 'top_k':40, 'min_p':0,
                    'repeat_penalty':1.1, 'seed':42, 'num_ctx':512, 'num_predict':10, 'context_behavior':'stop'}
        requests = []

        def stream(url, path, body, job):
            requests.append(body)
            yield {'response':'hello', 'done':False, 'logprobs':[{'token':'hello'}]}
            yield {'response':'', 'done':True, 'prompt_eval_count':5, 'eval_count':2, 'done_reason':'stop'}

        with patch('sampling.backends.stream_json', stream):
            first = list(model.generate('FIRST INPUT', settings, Job()))
            second = list(model.generate('SECOND INPUT', settings, Job()))
        self.assertEqual(first[0]['token_count'], 1)
        self.assertEqual(second[-1]['output_tokens'], 2)
        self.assertEqual(requests[1]['prompt'], 'SECOND INPUT')
        self.assertTrue(requests[1]['raw'])
        self.assertFalse(requests[1]['shift'])
        self.assertFalse(requests[1]['think'])
        for body in requests:
            self.assertNotIn('messages', body)
            self.assertNotIn('context', body)

    def test_llamacpp_uses_its_template_and_disables_prompt_cache(self):
        def respond(url, path, body=None, **kwargs):
            if path == '/props': return {'default_generation_settings':{'n_ctx':4096}}
            if path == '/apply-template': return {'prompt':'<user>' + body['messages'][0]['content'] + '</user><assistant>'}
            self.fail(path)
        with patch('sampling.backends.json_request', respond):
            model = LlamaCppModel('http://127.0.0.1:8080', 'fixture')
        self.assertEqual(model.prefix, '<user>')
        self.assertEqual(model.suffix, '</user><assistant>')
        settings = {'temperature':0.1, 'top_p':0.9, 'top_k':20, 'min_p':0,
                    'repeat_penalty':1, 'seed':42, 'num_predict':2}
        with patch('sampling.backends.stream_json', return_value=iter([{'content':'ok', 'stop':True, 'tokens':[2],
                                                                      'timings':{'prompt_n':10, 'predicted_n':1}}])) as stream:
            self.assertEqual(list(model.generate('input', settings, Job()))[0]['output_tokens'], 1)
            self.assertFalse(stream.call_args.args[2]['cache_prompt'])

    def test_zero_context_uses_an_explicit_engine_minimum(self):
        from sampling.context import validate_settings
        model = OllamaModel.__new__(OllamaModel)
        model.url, model.model, model.stop = 'http://127.0.0.1:11434', 'fixture', []
        settings = validate_settings({'num_ctx':0})
        with patch('sampling.backends.stream_json', return_value=iter([])) as stream:
            list(model.generate('<startup>', settings, Job()))
        self.assertEqual(stream.call_args.args[2]['options']['num_ctx'], 64)
        self.assertEqual(settings['num_ctx'], 0)

    def test_remote_byte_pieces_align_unicode_without_replacement(self):
        data = {'tokens':[{'id':0, 'piece':'<BOS>'}, {'id':1, 'piece':'A'},
                          {'id':2, 'piece':[240,159]}, {'id':3, 'piece':[152,128]}, {'id':4, 'piece':'é'}]}
        with patch('sampling.tokenization.json_request', return_value=data):
            tokens = ServerTokenizer('http://127.0.0.1:8080').encode('A😀é', add_bos=True)
        self.assertEqual([(t.start, t.end) for t in tokens], [(0,0), (0,1), (1,2), (1,2), (2,3)])

    def test_unsupported_tokenizer_is_explicit(self):
        with self.assertRaisesRegex(ModelError, 'supports Ollama'):
            LocalTokenizer({'tokenizer.ggml.model':'llama'})

    def test_only_loopback_http_addresses_are_allowed(self):
        for url in ['https://127.0.0.1:11434', 'http://example.com', 'http://localhost.evil.test',
                    'http://127.0.0.1:11434/api', 'http://user:pass@localhost', 'http://localhost:bad']:
            with self.subTest(url=url), self.assertRaises(ModelError): validate_url(url)
        self.assertEqual(validate_url('http://localhost:1234'), ('localhost',1234))

    def test_cancel_interrupts_an_active_socket(self):
        from unittest.mock import Mock
        job = Job()
        connection = Mock()
        connection.sock.detach.return_value = -1
        job.attach(connection)
        job.cancel()
        self.assertTrue(job.cancelled.is_set())
        connection.sock.shutdown.assert_called_once()


class FixtureHandler(BaseHTTPRequestHandler):
    def log_message(self, *_): pass

    def do_POST(self):
        self.rfile.read(int(self.headers['Content-Length']))
        self.send_response(200)
        self.send_header('Connection','close')
        self.end_headers()
        if self.path == '/waiting':
            self.wfile.write(b'{"response":"first","done":false}\n')
            self.wfile.flush()
            self.server.release.wait(3)
            return
        if self.path == '/ndjson':
            self.wfile.write(b'{"response":"hello","done":false}\n{"done":true}\n')
        else:
            self.wfile.write(b'event: message\ndata: {"content":"hello"}\n\ndata: [DONE]\n')


class StreamingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1',0), FixtureHandler)
        cls.server.release = threading.Event()
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.release.set()
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def test_ollama_ndjson(self):
        parts = list(stream_json(self.url, '/ndjson', {}, Job()))
        self.assertEqual(parts[0]['response'], 'hello')
        self.assertTrue(parts[-1]['done'])

    def test_llamacpp_sse(self):
        parts = list(stream_json(self.url, '/sse', {}, Job()))
        self.assertEqual(parts, [{'content':'hello'}])

    def test_cancel_with_connection_close_interrupts_waiting_stream(self):
        job = Job()
        iterator = stream_json(self.url, '/waiting', {}, job)
        self.assertEqual(next(iterator)['response'], 'first')
        # http.client has already detached the socket from the connection due
        # to the server's Connection: close header. Stop must still reach it.
        self.assertIsNone(job.connection.sock)
        errors = []
        def consume():
            try:
                list(iterator)
            except Exception as exc:
                errors.append(exc)
        worker = threading.Thread(target=consume, daemon=True)
        worker.start()
        job.cancel()
        worker.join(1)
        self.assertFalse(worker.is_alive(), 'Cancellation did not interrupt the detached response socket')
        self.assertEqual(errors, [])


if __name__ == '__main__': unittest.main()
