"""Exercise the browser stream contract, including zero-budget stop behavior."""
import http.client
import json
import threading
import unittest
import uuid
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from app import Handler
from sampling.tokenization import Token, token_spans


class Tokenizer:
    name = 'Unicode character fixture'

    def encode(self, text, add_bos=False):
        return [Token(ord(char), i, i + 1) for i, char in enumerate(text)]


class Model:
    tokenizer = Tokenizer()
    prefix, suffix = '<user>', '</user><assistant>'
    max_context, stop = 4096, []

    def __init__(self):
        self.requests = []

    def runtime_context(self):
        return 64

    def generate(self, compiled, settings, job):
        self.requests.append((compiled, settings.copy()))
        yield {'text':'café ', 'thinking':'', 'token_count':5, 'done':False}
        yield {'text':'😀\n<script>', 'thinking':'', 'token_count':10, 'done':False}
        yield {'text':'', 'thinking':'', 'token_count':0, 'done':True,
               'prompt_tokens':len(compiled), 'output_tokens':15, 'reason':'length'}


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.model = Model()
        self.patch = patch('app.get_model', return_value=self.model)
        self.patch.start()
        self.server = ThreadingHTTPServer(('127.0.0.1',0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.patch.stop()

    def run_model(self, settings):
        conn = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        body = {'source':'PRIVATE SOURCE', 'prompt':'PRIVATE PROMPT', 'settings':settings,
                'run_id':str(uuid.uuid4())}
        conn.request('POST', '/api/generate', json.dumps(body), {'Content-Type':'application/json'})
        response = conn.getresponse()
        self.assertEqual(response.status, 200)
        events = [json.loads(line) for line in response]
        conn.close()
        self.assertFalse([event for event in events if event['type'] == 'error'], events)
        return events

    def test_zero_budget_still_generates_without_any_pasted_content(self):
        events = self.run_model({'num_ctx':0, 'num_predict':16})
        self.assertEqual(self.model.requests[0][0], Model.prefix + Model.suffix)
        self.assertNotIn('PRIVATE', self.model.requests[0][0])
        self.assertTrue(any(event['type'] == 'chunk' and event.get('token_view') for event in events))

    def test_finished_output_has_unicode_offsets_and_real_token_ids(self):
        events = self.run_model({'num_ctx':512, 'num_predict':16})
        output = ''.join(event.get('text','') for event in events if event['type'] == 'chunk')
        done = next(event for event in events if event['type'] == 'done')
        spans = done['token_view']['output']
        self.assertEqual(spans, token_spans(self.model.tokenizer, output))
        self.assertEqual(''.join(output[t['start']:t['end']] for t in spans), output)
        self.assertEqual(spans[5]['id'], ord('😀'))

    def test_stop_when_full_with_zero_budget_does_not_call_engine(self):
        events = self.run_model({'num_ctx':0, 'context_behavior':'stop'})
        self.assertEqual(self.model.requests, [])
        self.assertFalse(any(event['type'] == 'chunk' for event in events))
        done = next(event for event in events if event['type'] == 'done')
        self.assertEqual(done['reason'], 'length')
        self.assertEqual(done['generated'], 0)


if __name__ == '__main__':
    unittest.main()
