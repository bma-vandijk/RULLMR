import unittest

from sampling.context import prepare, validate_settings
from sampling.tokenization import Token
from sampling.transport import ModelError


class CharacterTokenizer:
    name = 'Character fixture'

    def encode(self, text, add_bos=False):
        return [Token(ord(char), i, i + 1) for i, char in enumerate(text)]


class Model:
    prefix = '<user>'
    suffix = '</user><assistant>'
    max_context = 10000
    stop = ['</assistant>']
    tokenizer = CharacterTokenizer()


class ContextTests(unittest.TestCase):
    def test_empty_editors_have_zero_tokens(self):
        _, view = prepare(Model(), '', '', validate_settings({}))
        self.assertEqual(view['source'], [])
        self.assertEqual(view['prompt'], [])
        self.assertEqual(view['overhead_tokens'], view['input_tokens'])

    def test_large_window_keeps_everything_and_counts_framing(self):
        compiled, view = prepare(Model(), 'hello', 'summarize', validate_settings({'num_ctx':512}))
        self.assertEqual(view['input_tokens'], len(compiled))
        self.assertEqual(view['omitted_tokens'], 0)
        self.assertEqual(view['remaining'], 512 - len(compiled))
        self.assertEqual(len(view['source']) + len(view['prompt']) + view['overhead_tokens'], len(compiled))
        self.assertTrue(all(t['index'] is not None for t in view['source'] + view['prompt']))

    def test_cutoff_keeps_tail_and_instruction_gets_priority(self):
        source, prompt = 'abcdefghijklmnopqrstuvwxyz' * 20, 'KEEP THIS INSTRUCTION'
        compiled, view = prepare(Model(), source, prompt, validate_settings({'num_ctx':100}))
        self.assertLessEqual(view['input_tokens'], 99)
        self.assertGreater(view['source_cut'], 0)
        self.assertEqual(view['prompt_cut'], 0)
        self.assertIn(prompt, compiled)
        self.assertIn(source[view['source_cut']:], compiled)
        self.assertEqual(view['source_cut'], view['omitted_tokens'])
        self.assertEqual(''.join(source[t['start']:t['end']] for t in view['source']), source)

    def test_long_instruction_drops_source_before_instruction(self):
        compiled, view = prepare(Model(), 'source' * 50, 'instruction' * 50, validate_settings({'num_ctx':80}))
        self.assertEqual(view['source_cut'], 300)
        self.assertGreater(view['prompt_cut'], 0)
        self.assertLessEqual(view['input_tokens'], 79)
        self.assertTrue(compiled.endswith(Model.suffix))

    def test_unicode_is_preserved_across_cutoff(self):
        source = '🧑🏽‍🔬 café 漢字\n' * 50
        compiled, view = prepare(Model(), source, 'résumé', validate_settings({'num_ctx':90}))
        self.assertEqual(source[view['source_cut']:], compiled.split('Source text:\n')[1].split('\n\n---')[0])
        self.assertNotIn('\ufffd', compiled)
        self.assertEqual(''.join(source[t['start']:t['end']] for t in view['source']), source)

    def test_compiled_indices_map_back_to_editor_text(self):
        source, prompt = 'abcdef' * 100, 'instruction'
        compiled, view = prepare(Model(), source, prompt, validate_settings({'num_ctx':96}))
        for text, entries in [(source, view['source']), (prompt, view['prompt'])]:
            for token in entries:
                if token['index'] is not None:
                    self.assertEqual(compiled[token['index']], text[token['start']:token['end']])

    def test_inputs_do_not_leak_between_plans(self):
        prepare(Model(), 'SECRET_PREVIOUS_SOURCE', 'OLD_PROMPT', validate_settings({}))
        compiled, _ = prepare(Model(), 'new', 'new instruction', validate_settings({}))
        self.assertNotIn('SECRET_PREVIOUS_SOURCE', compiled)
        self.assertNotIn('OLD_PROMPT', compiled)

    def test_longer_prompt_reduces_source_capacity(self):
        _, short = prepare(Model(), 'x' * 500, 'short', validate_settings({'num_ctx':100}))
        _, long = prepare(Model(), 'x' * 500, 'a much longer instruction', validate_settings({'num_ctx':100}))
        self.assertGreater(long['source_cut'], short['source_cut'])

    def test_switch_reverses_the_serialized_input(self):
        compiled, view = prepare(Model(), 'source', 'prompt', validate_settings({'input_order':'prompt_first'}))
        self.assertLess(compiled.index('Instruction:'), compiled.index('Source text:'))
        self.assertLess(compiled.index('prompt'), compiled.index('source'))
        self.assertEqual(view['input_order'], 'prompt_first')
        self.assertEqual(view['omitted_tokens'], 0)

    def test_prompt_first_drops_instruction_before_source(self):
        source, prompt = 'KEEP THIS SOURCE', 'instruction' * 50
        compiled, view = prepare(Model(), source, prompt, validate_settings({'num_ctx':100, 'input_order':'prompt_first'}))
        self.assertGreater(view['prompt_cut'], 0)
        self.assertEqual(view['source_cut'], 0)
        self.assertIn(source, compiled)
        self.assertLessEqual(view['input_tokens'], 99)
        for text, entries in [(source, view['source']), (prompt, view['prompt'])]:
            for token in entries:
                if token['index'] is not None:
                    self.assertEqual(compiled[token['index']], text[token['start']:token['end']])

    def test_prompt_first_drops_entire_prompt_if_source_alone_fills_window(self):
        compiled, view = prepare(Model(), 'source' * 50, 'instruction' * 50,
                                 validate_settings({'num_ctx':80, 'input_order':'prompt_first'}))
        self.assertEqual(view['prompt_cut'], 550)
        self.assertGreater(view['source_cut'], 0)
        self.assertTrue(all(t['index'] is None for t in view['prompt']))
        self.assertLessEqual(view['input_tokens'], 79)
        self.assertTrue(compiled.endswith(Model.suffix))

    def test_longer_source_reduces_prompt_capacity_when_prompt_first(self):
        settings = validate_settings({'num_ctx':100, 'input_order':'prompt_first'})
        _, short = prepare(Model(), 'short', 'x' * 500, settings)
        _, long = prepare(Model(), 'a much longer source text', 'x' * 500, settings)
        self.assertGreater(long['prompt_cut'], short['prompt_cut'])

    def test_failure_preset_extremes_are_valid(self):
        result = validate_settings({'num_ctx':64, 'temperature':2, 'num_predict':8, 'repeat_penalty':4})
        self.assertEqual(result['repeat_penalty'], 4)

    def test_model_capacity_is_enforced(self):
        with self.assertRaises(ModelError):
            prepare(Model(), '', '', validate_settings({'num_ctx':20000}))

    def test_zero_context_omits_every_input_token_and_keeps_only_startup_markers(self):
        for order in ['source_first', 'prompt_first']:
            with self.subTest(order=order):
                source, prompt = 'café 😀 <source>', 'Keep this instruction'
                compiled, view = prepare(Model(), source, prompt,
                                         validate_settings({'num_ctx':0, 'input_order':order}))
                self.assertEqual(compiled, Model.prefix + Model.suffix)
                self.assertEqual(view['remaining'], 0)
                self.assertEqual(view['context'], 0)
                self.assertTrue(view['framing_only'])
                self.assertTrue(all(t['index'] is None for t in view['source'] + view['prompt']))
                self.assertEqual(view['omitted_tokens'], len(source) + len(prompt))
                self.assertEqual(view['source_cut'], len(source))
                self.assertEqual(view['prompt_cut'], len(prompt))
                self.assertEqual(view['input_tokens'], view['overhead_tokens'])

    def test_context_below_framing_cost_also_excludes_all_input(self):
        for context in [1, 8, 30]:
            with self.subTest(context=context):
                compiled, view = prepare(Model(), 'source', 'prompt', validate_settings({'num_ctx':context}))
                self.assertEqual(compiled, Model.prefix + Model.suffix)
                self.assertEqual(view['omitted_tokens'], 12)
                self.assertEqual(view['remaining'], 0)

    def test_invalid_settings_are_rejected(self):
        for values in [{'num_ctx':-1}, {'top_k':1.5}, {'temperature':float('nan')}, {'seed':True},
                       {'top_p':2}, {'num_predict':0}, {'context_behavior':'unknown'},
                       {'input_order':'unknown'}, {'repeat_penalty':11}]:
            with self.subTest(values=values), self.assertRaises(ModelError):
                validate_settings(values)


if __name__ == '__main__':
    unittest.main()
