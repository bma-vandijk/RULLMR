import assert from 'node:assert/strict';
import {test} from 'node:test';
import {responseTokenOutside} from '../web/context-view.js';

function run(context, generated, thinking=0) {
  return {preview:{context, input_tokens:context ? context - 1 : 8}, generated,
    config:{settings:{num_ctx:context}}, token_view:{thinking:Array(thinking).fill({})}};
}

test('Input can slide out while every response token still fits', () => {
  const active = run(64,64);
  for (let index=0; index<64; index++) assert.equal(responseTokenOutside(active,'output',[index]),false);
});

test('The 65th generated token evicts only the first response token in a 64-token view', () => {
  const active = run(64,65);
  assert.equal(responseTokenOutside(active,'output',[0]),true);
  assert.equal(responseTokenOutside(active,'output',[1]),false);
  assert.equal(responseTokenOutside(active,'output',[64]),false);
});

test('A long response keeps exactly its most recent window of tokens', () => {
  const active = run(64,160);
  const visible = Array.from({length:160},(_,index)=>index).filter(index => !responseTokenOutside(active,'output',[index]));
  assert.equal(visible.length,64);
  assert.equal(visible[0],96);
  assert.equal(visible.at(-1),159);
});

test('Zero context grays every response token, including overlapping Unicode pieces', () => {
  assert.equal(responseTokenOutside(run(0,2),'output',[0,1]),true);
});

test('Thinking consumes the same window before the visible response', () => {
  const active = run(4,7,3);
  assert.equal(responseTokenOutside(active,'thinking',[2]),true);
  assert.equal(responseTokenOutside(active,'output',[0]),false);
  active.generated++;
  assert.equal(responseTokenOutside(active,'output',[0]),true);
  assert.equal(responseTokenOutside(active,'output',[1]),false);
});

test('Final EOS counts can push an additional visible token outside the window', () => {
  assert.equal(responseTokenOutside(run(4,5),'output',[0]),true);
  assert.equal(responseTokenOutside(run(4,5),'output',[1]),false);
});

test('Overlapping byte pieces turn gray together when any part is outside', () => {
  assert.equal(responseTokenOutside(run(4,6),'output',[1,2]),true);
  assert.equal(responseTokenOutside(run(4,6),'output',[2,3]),false);
});

test('Completed runs retain their own context and count after settings for the next run change', () => {
  const completed = run(4,8);
  delete completed.generated;
  completed.metrics = {generated:8};
  completed.config.settings.num_ctx = 4096;
  assert.equal(responseTokenOutside(completed,'output',[3]),true);
  assert.equal(responseTokenOutside(completed,'output',[4]),false);
});
