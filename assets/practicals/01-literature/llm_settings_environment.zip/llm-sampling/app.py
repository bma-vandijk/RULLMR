"""LLM Sampling: a loopback-only web app. Run with python app.py --open."""
import argparse
import json
import mimetypes
import os
from pathlib import Path
import shutil
import subprocess
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from sampling.backends import discover, discover_one, get_model
from sampling.context import prepare, validate_settings, validate_text
from sampling.tokenization import token_spans
from sampling.transport import Job, ModelError


ROOT = Path(__file__).resolve().parent
JOBS = {}
JOBS_LOCK = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *_):
        pass  # Never log pasted source text or prompts.

    def send_json(self, data, status=200):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)

    def same_origin(self):
        allowed = {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}
        host = self.headers.get('Host', '')
        origin = self.headers.get('Origin')
        return host in allowed and (not origin or origin in {f'http://{h}' for h in allowed})

    def do_GET(self):
        if not self.same_origin():
            self.send_json({'error': 'Open this app using its local address.'}, 403)
            return
        route = self.path.split('?', 1)[0]
        if route == '/api/health':
            self.send_json({'app': 'llm-sampling', 'version': 1})
        elif route == '/api/discover':
            self.send_json({'servers': discover(), 'ollama_installed': bool(shutil.which('ollama'))})
        elif route in ('/', '/index.html', '/app.js', '/context-view.js', '/styles.css', '/favicon.svg'):
            filename = 'index.html' if route == '/' else route.lstrip('/')
            path = ROOT / 'web' / filename
            raw = path.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', (mimetypes.guess_type(str(path))[0] or 'application/octet-stream') + '; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(raw)
        else:
            self.send_json({'error': 'Not found.'}, 404)

    def read_body(self):
        try:
            size = int(self.headers.get('Content-Length', '0'))
        except ValueError as exc:
            raise ModelError('Invalid request length.') from exc
        if size <= 0 or size > 12000000:
            raise ModelError('Request is empty or too large.')
        data = json.loads(self.rfile.read(size))
        if not isinstance(data, dict):
            raise ModelError('The request must be a JSON object.')
        return data

    def do_POST(self):
        if not self.same_origin() or 'application/json' not in self.headers.get('Content-Type', ''):
            self.send_json({'error': 'Only requests from the local app are accepted.'}, 403)
            return
        try:
            data = self.read_body()
            if self.path == '/api/connect':
                self.send_json(discover_one(data.get('backend'), data.get('url', '')))
            elif self.path == '/api/preview':
                _, preview = self.plan(data)
                self.send_json(preview)
            elif self.path == '/api/generate':
                self.generate(data)
            elif self.path == '/api/cancel':
                with JOBS_LOCK:
                    job = JOBS.get(data.get('run_id'))
                if job:
                    job.cancel()
                self.send_json({'stopped': bool(job)})
            elif self.path == '/api/start-ollama':
                executable = shutil.which('ollama')
                if not executable:
                    raise ModelError('Ollama is not installed. Install it from ollama.com first.')
                if discover_one('ollama', 'http://127.0.0.1:11434')['online']:
                    self.send_json({'started': True})
                    return
                subprocess.Popen([executable, 'serve'], stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
                self.send_json({'started': True})
            else:
                self.send_json({'error': 'Not found.'}, 404)
        except (ModelError, ValueError, TypeError, KeyError) as exc:
            self.send_json({'error': str(exc)}, 400)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as exc:
            self.send_json({'error': f'Unexpected error: {exc}'}, 500)

    def plan(self, data):
        settings = validate_settings(data.get('settings', {}))
        model = get_model(data.get('backend'), data.get('url', ''), data.get('model'))
        source = validate_text(data.get('source', ''), 'Source text')
        prompt = validate_text(data.get('prompt', ''), 'Prompt')
        compiled, preview = prepare(model, source, prompt, settings)
        return (model, compiled, settings), preview

    def generate(self, data):
        run_id = str(data.get('run_id', ''))
        try:
            uuid.UUID(run_id)
        except ValueError as exc:
            raise ModelError('Invalid run identifier.') from exc
        if not data.get('prompt', '').strip():
            raise ModelError('Write a prompt before running the model.')
        job = Job()
        with JOBS_LOCK:
            if run_id in JOBS:
                raise ModelError('This run is already active.')
            if JOBS:
                raise ModelError('Another run is active. Stop it or wait for it to finish.')
            JOBS[run_id] = job
        self.send_response(200)
        self.send_header('Content-Type', 'application/x-ndjson; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Connection', 'close')
        self.end_headers()
        self.close_connection = True

        def emit(event):
            self.wfile.write((json.dumps(event, ensure_ascii=False) + '\n').encode('utf-8'))
            self.wfile.flush()

        output, thinking = '', ''
        produced, has_counts = 0, False
        try:
            emit({'type': 'status', 'text': 'Preparing a fresh context…'})
            (model, compiled, settings), preview = self.plan(data)
            if job.cancelled.is_set():
                emit({'type': 'done', 'reason': 'stopped', 'generated': 0})
                return
            if settings['context_behavior'] == 'stop':
                settings['num_predict'] = min(settings['num_predict'], preview['remaining'])
            emit({'type': 'start', 'preview': preview, 'output_limit': settings['num_predict']})
            if settings['num_predict'] == 0:
                emit({'type': 'done', 'reason': 'length', 'generated': 0,
                      'token_view': {'output': [], 'thinking': []}})
                return
            start = time.monotonic()
            last_token_view = 0

            def color_view():
                return {'output': token_spans(model.tokenizer, output),
                        'thinking': token_spans(model.tokenizer, thinking) if thinking else []}

            done = False
            capacity_checked = False
            engine_context = None
            for part in model.generate(compiled, settings, job):
                if job.cancelled.is_set():
                    break
                if not capacity_checked:
                    capacity_checked = True
                    engine_context = model.runtime_context()
                    if engine_context:
                        emit({'type': 'capacity', 'engine_context': engine_context})
                output += part['text']
                thinking += part['thinking']
                if part['token_count']:
                    has_counts = True
                    produced += part['token_count']
                elif not has_counts:
                    produced = len(model.tokenizer.encode(thinking + output))
                if part.get('done') and part.get('output_tokens') is not None:
                    produced = part['output_tokens']
                if part['text'] or part['thinking'] or part['token_count']:
                    event = {'type': 'chunk', 'text': part['text'], 'thinking': part['thinking'],
                             'generated': produced, 'count_exact': has_counts}
                    if time.monotonic() - last_token_view >= 0.08:
                        event['token_view'] = color_view()
                        last_token_view = time.monotonic()
                    emit(event)
                if part['done']:
                    duration = (part.get('duration_ns') or 0) / 1e9
                    actual_input = part.get('prompt_tokens')
                    emit({'type': 'done', 'reason': part.get('reason') or 'stop', 'generated': produced,
                          'actual_input': actual_input, 'planned_input': preview['input_tokens'],
                          'engine_context': engine_context,
                          'elapsed': time.monotonic() - start,
                          'tokens_per_second': round(produced / duration, 1) if duration else None,
                          'token_view': color_view(),
                          'count_exact': part.get('output_tokens') is not None})
                    done = True
                    break
            if not done:
                if job.cancelled.is_set():
                    emit({'type': 'done', 'reason': 'stopped', 'generated': produced,
                          'token_view': color_view()})
                else:
                    emit({'type': 'error', 'error': 'The model stream ended before completion. The partial output is kept.'})
        except (BrokenPipeError, ConnectionResetError):
            job.cancel()
        except Exception as exc:
            if job.cancelled.is_set():
                emit({'type': 'done', 'reason': 'stopped', 'generated': produced})
            else:
                emit({'type': 'error', 'error': str(exc)})
        finally:
            with JOBS_LOCK:
                JOBS.pop(run_id, None)


def main():
    parser = argparse.ArgumentParser(description='Local LLM Sampling playground')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--open', action='store_true', help='Open the app in your browser')
    args = parser.parse_args()
    url = f'http://127.0.0.1:{args.port}'
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    except OSError:
        from sampling.transport import json_request
        try:
            if json_request(url, '/api/health', timeout=2).get('app') == 'llm-sampling':
                if args.open:
                    webbrowser.open(url)
                return
        except Exception:
            pass
        raise SystemExit(f'Port {args.port} is in use. Start with --port 8766.')
    print(f'LLM Sampling is running at {url}\nClose this window or press Ctrl+C to stop.')
    if args.open:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        with JOBS_LOCK:
            for job in JOBS.values():
                job.cancel()
        server.server_close()


if __name__ == '__main__':
    main()
