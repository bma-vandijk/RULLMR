"""Fit the serialized input, dropping characters from the first section first."""
import math

from .transport import ModelError


LIMITS = {'num_ctx': (0, 1048576, int), 'num_predict': (1, 32768, int),
          'temperature': (0, 2, float), 'top_p': (0, 1, float), 'top_k': (0, 1000, int),
          'min_p': (0, 1, float), 'repeat_penalty': (0, 10, float), 'seed': (-1, 2147483647, int)}
DEFAULTS = {'num_ctx': 4096, 'num_predict': 512, 'temperature': 0.7, 'top_p': 0.9,
            'top_k': 40, 'min_p': 0.0, 'repeat_penalty': 1.1, 'seed': -1,
            'context_behavior': 'slide', 'input_order': 'source_first'}


def validate_settings(values):
    if not isinstance(values, dict):
        raise ModelError('Settings must be an object.')
    result = DEFAULTS.copy()
    for key, (lower, upper, kind) in LIMITS.items():
        value = values.get(key, result[key])
        try:
            if isinstance(value, bool):
                raise ValueError()
            number = float(value)
            if not math.isfinite(number) or not lower <= number <= upper or (kind is int and number != int(number)):
                raise ValueError()
            result[key] = kind(number)
        except (ValueError, TypeError, OverflowError) as exc:
            raise ModelError(f'{key} must be between {lower} and {upper}'
                             + (' and a whole number.' if kind is int else '.')) from exc
    result['context_behavior'] = values.get('context_behavior', 'slide')
    if result['context_behavior'] not in ('slide', 'stop'):
        raise ModelError('Choose Slide or Stop when full for the context behavior.')
    result['input_order'] = values.get('input_order', 'source_first')
    if result['input_order'] not in ('source_first', 'prompt_first'):
        raise ModelError('Choose source first or prompt first for the input order.')
    return result


def validate_text(value, label):
    if not isinstance(value, str):
        raise ModelError(f'{label} must be text.')
    if len(value) > 1000000:
        raise ModelError(f'{label} is too large. Use at most one million characters.')
    return value


def prepare(model, source, prompt, settings):
    if settings['num_ctx'] > model.max_context:
        raise ModelError(f'This model supports at most {model.max_context:,} context tokens.')
    tokenizer = model.tokenizer
    order = ('prompt', 'source') if settings['input_order'] == 'prompt_first' else ('source', 'prompt')
    texts = {'source': source, 'prompt': prompt}
    labels = {'source': 'Source text:\n', 'prompt': 'Instruction:\n'}
    cuts = {'source': 0, 'prompt': 0}

    def serialize(current_cuts):
        compiled, starts = model.prefix, {}
        for index, section in enumerate(order):
            if index:
                compiled += '\n\n---\n'
            compiled += labels[section]
            starts[section] = len(compiled)
            compiled += texts[section][current_cuts[section]:]
        return compiled + model.suffix, starts['source'], starts['prompt']

    full, _, _ = serialize(cuts)
    original_count = len(tokenizer.encode(full, add_bos=True))
    budget = settings['num_ctx'] - 1  # reserve a slot for the next generated token
    empty_cuts = {name: len(texts[name]) for name in order}
    framing_count = len(tokenizer.encode(serialize(empty_cuts)[0], add_bos=True))
    framing_only = budget < framing_count

    # A model needs startup markers to generate. Below their cost (including
    # zero), omit all user content and report those markers separately.
    if framing_only:
        compiled = model.prefix + model.suffix
        encoded = tokenizer.encode(compiled, add_bos=True)
        items = {name: [{'id': t.id, 'start': t.start, 'end': t.end, 'index': None}
                        for t in tokenizer.encode(text)] for name, text in texts.items()}
        preview = {'source': items['source'], 'prompt': items['prompt'],
                   'source_text': source, 'prompt_text': prompt,
                   'source_cut': len(source), 'prompt_cut': len(prompt),
                   'input_tokens': len(encoded), 'original_tokens': original_count,
                   'overhead_tokens': len(encoded),
                   'omitted_tokens': len(items['source']) + len(items['prompt']),
                   'context': settings['num_ctx'], 'remaining': 0,
                   'input_order': settings['input_order'], 'framing_only': True,
                   'tokenizer': tokenizer.name, 'max_context': model.max_context,
                   'compiled_prompt': compiled,
                   'context_note': 'All source and prompt tokens are excluded. Only the model’s startup '
                                   'markers are sent. The engine still uses its minimum context capacity; '
                                   'generated text is outside the selected context view.'}
        return compiled, preview

    def count(current_cuts):
        return len(tokenizer.encode(serialize(current_cuts)[0], add_bos=True))

    def trim(text, fits):
        # Cut only at original token boundaries, grouping overlapping UTF-8 pieces.
        boundaries = sorted({0, len(text), *(t.end for t in tokenizer.encode(text))})
        low, high = 0, len(boundaries) - 1
        while low < high:
            mid = (low + high) // 2
            if fits(boundaries[mid]):
                high = mid
            else:
                low = mid + 1
        return boundaries[low]

    if original_count > budget:
        for section in order:
            if count(cuts) <= budget:
                break
            cuts[section] = trim(texts[section], lambda cut: count({**cuts, section: cut}) <= budget)
    compiled, source_start, prompt_start = serialize(cuts)
    encoded = tokenizer.encode(compiled, add_bos=True)
    # BPE length can change at a cut boundary. Recheck the final serialized input.
    while len(encoded) > budget:
        section = next((name for name in order if cuts[name] < len(texts[name])), None)
        if section is None:
            break
        cuts[section] += 1
        compiled, source_start, prompt_start = serialize(cuts)
        encoded = tokenizer.encode(compiled, add_bos=True)
    if len(encoded) > budget:
        raise ModelError('The context is too small for this model’s prompt framing. Increase it.')

    def entries(text, cut, start):
        items = [{'id': t.id, 'start': t.start, 'end': t.end, 'index': None}
                 for t in tokenizer.encode(text[:cut])]
        end = start + len(text) - cut
        if end == start:
            return items
        for index, token in enumerate(encoded):
            if token.end > start and token.start < end:
                items.append({'id': token.id, 'start': max(token.start, start) - start + cut,
                              'end': min(token.end, end) - start + cut, 'index': index})
        return items

    source_cut, prompt_cut = cuts['source'], cuts['prompt']
    source_items = entries(source, source_cut, source_start)
    prompt_items = entries(prompt, prompt_cut, prompt_start)
    visible_indices = {t['index'] for t in source_items + prompt_items if t['index'] is not None}
    omitted = sum(t['index'] is None for t in source_items + prompt_items)
    preview = {'source': source_items, 'prompt': prompt_items,
               'source_text': source, 'prompt_text': prompt, 'source_cut': source_cut, 'prompt_cut': prompt_cut,
               'input_tokens': len(encoded), 'original_tokens': original_count,
               'overhead_tokens': len(encoded) - len(visible_indices), 'omitted_tokens': omitted,
               'context': settings['num_ctx'], 'remaining': settings['num_ctx'] - len(encoded),
               'input_order': settings['input_order'],
               'tokenizer': tokenizer.name, 'max_context': model.max_context,
               'compiled_prompt': compiled,
               'context_note': ('llama.cpp capacity is set when the server starts. This setting enforces '
                                'the input cutoff here; the live slide is a projection.'
                                if not hasattr(model, 'stop') else
                                'Initial gray tokens are excluded from the request. During generation, '
                                'gray tokens show a projected rolling window; Ollama may shift in blocks '
                                'or use model-specific memory.')}
    return compiled, preview
