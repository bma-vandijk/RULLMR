"""Reconstruct supported GGUF BPE tokenizers from Ollama's own vocabulary."""
from bisect import bisect_left, bisect_right
from dataclasses import dataclass

from tokenizers import AddedToken, Regex, Tokenizer, decoders, models, pre_tokenizers

from .transport import ModelError, json_request


QWEN = r"(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\r\n\p{L}\p{N}]?\p{L}+|\p{N}| ?[^\s\p{L}\p{N}]+[\r\n]*|\s*[\r\n]+|\s+(?!\S)|\s+"
QWEN35 = r"(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\r\n\p{L}\p{N}]?[\p{L}\p{M}]+|\p{N}| ?[^\s\p{L}\p{M}\p{N}]+[\r\n]*|\s*[\r\n]+|\s+(?!\S)|\s+"
LLAMA3 = r"(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\r\n\p{L}\p{N}]?\p{L}+|\p{N}{1,3}| ?[^\s\p{L}\p{N}]+[\r\n]*|\s*[\r\n]+|\s+(?!\S)|\s+"
PATTERNS = {'qwen2': QWEN, 'deepseek-r1-qwen': QWEN, 'qwen35': QWEN35,
            'llama-bpe': LLAMA3, 'llama3': LLAMA3}


@dataclass(frozen=True)
class Token:
    id: int
    start: int
    end: int


def token_spans(tokenizer, text):
    """Retokenize displayed text, preserving Unicode offsets for the color view."""
    return [{'id': token.id, 'start': token.start, 'end': token.end, 'index': index}
            for index, token in enumerate(tokenizer.encode(text))]


class LocalTokenizer:
    def __init__(self, metadata):
        pre = metadata.get('tokenizer.ggml.pre')
        vocab = metadata.get('tokenizer.ggml.tokens', [])
        merges = metadata.get('tokenizer.ggml.merges', [])
        if metadata.get('tokenizer.ggml.model') != 'gpt2' or pre not in PATTERNS or not vocab or not merges:
            raise ModelError('This version supports Ollama Qwen and Llama 3 BPE tokenizers. '
                             'Choose one of those models, or use llama.cpp with its native tokenizer.')
        self.name = f'Model BPE · {pre}'
        engine = Tokenizer(models.BPE(vocab={token: i for i, token in enumerate(vocab)},
                                      merges=[tuple(pair.split(' ', 1)) for pair in merges]))
        engine.pre_tokenizer = pre_tokenizers.Sequence([
            pre_tokenizers.Split(Regex(PATTERNS[pre]), behavior='isolated'),
            pre_tokenizers.ByteLevel(add_prefix_space=False, use_regex=False),
        ])
        engine.decoder = decoders.ByteLevel()
        types = metadata.get('tokenizer.ggml.token_type', [])
        specials = [AddedToken(token, special=True, normalized=False)
                    for token, kind in zip(vocab, types) if kind in (3, 4)]
        engine.add_special_tokens(specials)
        self.engine = engine
        self.bos = metadata.get('tokenizer.ggml.bos_token_id') if metadata.get('tokenizer.ggml.add_bos_token') else None

    def encode(self, text, add_bos=False):
        encoded = self.engine.encode(text, add_special_tokens=False)
        result = [Token(token_id, start, end) for token_id, (start, end) in zip(encoded.ids, encoded.offsets)]
        if add_bos and self.bos is not None and (not result or result[0].id != self.bos):
            result.insert(0, Token(self.bos, 0, 0))
        return result


class ServerTokenizer:
    name = 'Model tokenizer · llama.cpp'

    def __init__(self, url):
        self.url = url

    def encode(self, text, add_bos=False):
        result = json_request(self.url, '/tokenize', {
            'content': text, 'add_special': add_bos, 'parse_special': True, 'with_pieces': True,
        })['tokens']
        raw = text.encode('utf-8')
        boundaries = [0]
        for char in text:
            boundaries.append(boundaries[-1] + len(char.encode('utf-8')))
        cursor, tokens = 0, []
        for item in result:
            piece = item['piece']
            piece = bytes(piece) if isinstance(piece, list) else piece.encode('utf-8')
            if raw[cursor:cursor + len(piece)] == piece:
                start = bisect_right(boundaries, cursor) - 1
                cursor += len(piece)
                end = bisect_left(boundaries, cursor)
            elif cursor == 0 and add_bos:
                start = end = 0  # synthetic BOS has no source characters
            else:
                raise ModelError('This model normalizes its input in a way that cannot be aligned '
                                 'with the editor yet. Choose a Qwen model for the token view.')
            tokens.append(Token(item['id'], start, end))
        if cursor != len(raw):
            raise ModelError('The server tokenizer did not preserve all input characters.')
        return tokens
