import concurrent.futures
import threading

from .tokenization import LocalTokenizer, ServerTokenizer
from .transport import ModelError, json_request, stream_json, validate_url


DEFAULTS = [('ollama', 'http://127.0.0.1:11434'), ('llamacpp', 'http://127.0.0.1:8080')]
_cache = {}
_cache_lock = threading.Lock()


def discover_one(kind, url):
    validate_url(url)
    try:
        if kind == 'ollama':
            result = json_request(url, '/api/tags', timeout=2)
            available = [{'name': m['name'], 'size': m.get('size'),
                          'max_context': m.get('details', {}).get('context_length')}
                         for m in result.get('models', [])
                         if 'cloud' not in m['name'] and not m.get('remote_host')]
        elif kind == 'llamacpp':
            result = json_request(url, '/v1/models', timeout=2)
            available = [{'name': m['id']} for m in result.get('data', [])]
        else:
            raise ModelError('Choose Ollama or llama.cpp.')
        return {'kind': kind, 'url': url, 'online': True, 'models': available}
    except (ModelError, ValueError, KeyError) as exc:
        return {'kind': kind, 'url': url, 'online': False, 'models': [], 'error': str(exc)}


def discover():
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        return list(pool.map(lambda entry: discover_one(*entry), DEFAULTS))


class OllamaModel:
    def __init__(self, url, model):
        self.url, self.model = url, model
        info = json_request(url, '/api/show', {'model': model, 'verbose': True}, timeout=30)
        if info.get('remote_host') or info.get('remote_model') or 'cloud' in model:
            raise ModelError('Select a local model for this local sampling app.')
        if info.get('messages'):
            raise ModelError('This model contains preset conversations. Choose a model without preset messages.')
        metadata = info.get('model_info', {})
        self.tokenizer = LocalTokenizer(metadata)
        self.max_context = next((int(v) for k, v in metadata.items() if k.endswith('.context_length')), 32768)
        template = info.get('template', '')
        thinking = 'thinking' in info.get('capabilities', [])
        if '<|im_start|>' in template or 'qwen' in metadata.get('general.architecture', ''):
            self.prefix = '<|im_start|>user\n'
            self.suffix = '<|im_end|>\n<|im_start|>assistant\n'
            if thinking:
                self.suffix += '<think>\n\n</think>\n\n'
            self.stop = ['<|im_end|>', '<|endoftext|>']
        elif '<|start_header_id|>' in template:
            self.prefix = '<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n'
            self.suffix = '<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n'
            self.stop = ['<|eot_id|>', '<|end_of_text|>']
        else:
            raise ModelError('This model uses an unsupported prompt format. Choose a standard Qwen or Llama 3 model.')

    def generate(self, compiled, settings, job):
        options = {key: settings[key] for key in ('temperature', 'top_p', 'top_k', 'min_p',
                                                  'repeat_penalty', 'seed', 'num_ctx')}
        # num_ctx=0 can mean an engine default, rather than no pasted input.
        # Input cutoff is enforced by prepare(); use an explicit viable capacity.
        options['num_ctx'] = max(64, settings['num_ctx'])
        options.update(num_predict=settings['num_predict'], stop=self.stop, num_keep=0)
        body = {'model': self.model, 'prompt': compiled, 'raw': True, 'stream': True,
                'logprobs': True, 'keep_alive': '5m', 'think': False, 'options': options}
        if settings['context_behavior'] == 'stop':
            body['shift'] = False
        for part in stream_json(self.url, '/api/generate', body, job):
            yield {'text': part.get('response', ''), 'thinking': part.get('thinking', ''),
                   'token_count': len(part.get('logprobs', [])), 'done': part.get('done', False),
                   'reason': part.get('done_reason'), 'prompt_tokens': part.get('prompt_eval_count'),
                   'output_tokens': part.get('eval_count'), 'duration_ns': part.get('eval_duration')}

    def runtime_context(self):
        try:
            running = json_request(self.url, '/api/ps', timeout=2).get('models', [])
            return next((m.get('context_length') for m in running
                         if m.get('name') == self.model or m.get('model') == self.model), None)
        except (ModelError, ValueError):
            return None


class LlamaCppModel:
    def __init__(self, url, model):
        self.url, self.model = url, model
        props = json_request(url, '/props', timeout=10)
        generation = props.get('default_generation_settings', {})
        self.max_context = generation.get('n_ctx', 4096)
        self.tokenizer = ServerTokenizer(url)
        sentinel = '__LLM_SAMPLING_PAYLOAD_964d__'
        formatted = json_request(url, '/apply-template', {
            'messages': [{'role': 'user', 'content': sentinel}],
            'add_generation_prompt': True,
        }).get('prompt', '')
        if formatted.count(sentinel) != 1:
            raise ModelError('llama.cpp /apply-template did not return the expected prompt.')
        self.prefix, self.suffix = formatted.split(sentinel)

    def generate(self, compiled, settings, job):
        # Server context capacity is fixed when llama.cpp starts. The app always
        # enforces the requested input budget; the UI explains this distinction.
        body = {'prompt': compiled, 'stream': True, 'cache_prompt': False,
                'temperature': settings['temperature'], 'top_p': settings['top_p'],
                'top_k': settings['top_k'], 'min_p': settings['min_p'],
                'repeat_penalty': settings['repeat_penalty'], 'seed': settings['seed'],
                'n_predict': settings['num_predict'], 'n_keep': 0, 'return_tokens': True}
        for part in stream_json(self.url, '/completion', body, job):
            timings = part.get('timings', {})
            yield {'text': part.get('content', ''), 'thinking': '',
                   'token_count': len(part.get('tokens', [])), 'done': part.get('stop', False),
                   'reason': part.get('stop_type', 'stop') if part.get('stop') else None,
                   'prompt_tokens': timings.get('prompt_n'), 'output_tokens': timings.get('predicted_n'),
                   'duration_ns': (timings.get('predicted_ms') or 0) * 1e6}

    def runtime_context(self):
        return self.max_context


def get_model(kind, url, model):
    validate_url(url)
    if not isinstance(model, str) or not model or len(model) > 300:
        raise ModelError('Choose a model first.')
    key = (kind, url, model)
    with _cache_lock:
        if key not in _cache:
            if kind == 'ollama':
                _cache[key] = OllamaModel(url, model)
            elif kind == 'llamacpp':
                _cache[key] = LlamaCppModel(url, model)
            else:
                raise ModelError('Choose Ollama or llama.cpp.')
        return _cache[key]
