"""Small HTTP client with cancellable streaming, without extra dependencies."""
import http.client
import json
import socket
import threading
from urllib.parse import urlsplit


class ModelError(Exception):
    pass


def validate_url(url):
    if not isinstance(url, str):
        raise ModelError('Enter a local server address.')
    parts = urlsplit(url.rstrip('/'))
    if parts.scheme != 'http' or parts.hostname not in ('localhost', '127.0.0.1', '::1'):
        raise ModelError('Use a local HTTP address, such as http://127.0.0.1:11434.')
    if parts.username or parts.password or parts.query or parts.fragment or parts.path not in ('', '/'):
        raise ModelError('Enter the server address without a path, credentials, or query.')
    try:
        port = parts.port
    except ValueError as exc:
        raise ModelError('The server port is invalid.') from exc
    return parts.hostname, port or 80


class Job:
    def __init__(self):
        self.cancelled = threading.Event()
        self.lock = threading.Lock()
        self.connection = None
        self.socket = None

    def attach(self, connection):
        with self.lock:
            self.connection = connection
            self.socket = connection.sock
            if self.cancelled.is_set():
                raise ModelError('Run stopped.')

    def cancel(self):
        self.cancelled.set()
        with self.lock:
            active_socket = self.socket
            self.socket = None
            if active_socket:
                try:
                    active_socket.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                # On Windows, shutdown alone can leave an already-blocked recv
                # waiting. Detach and close this request's socket immediately,
                # even if HTTPResponse's file wrapper still holds an IO ref.
                try:
                    descriptor = active_socket.detach()
                    if descriptor != -1:
                        socket.close(descriptor)
                except OSError:
                    pass


def request(url, path, body=None, timeout=15, job=None):
    host, port = validate_url(url)
    conn = http.client.HTTPConnection(host, port, timeout=timeout)
    try:
        conn.connect()
        if job:
            job.attach(conn)
        payload = json.dumps(body, ensure_ascii=False).encode('utf-8') if body is not None else None
        conn.request('POST' if body is not None else 'GET', path, payload,
                     {'Content-Type': 'application/json', 'Accept': 'application/json'})
        response = conn.getresponse()
        if response.status >= 400:
            raw = response.read().decode('utf-8', errors='replace')
            try:
                detail = json.loads(raw).get('error', raw)
            except (ValueError, AttributeError):
                detail = raw
            raise ModelError(str(detail)[:1000] or f'Model server returned HTTP {response.status}.')
        return conn, response
    except (OSError, http.client.HTTPException) as exc:
        conn.close()
        if job and job.cancelled.is_set():
            raise ModelError('Run stopped.') from exc
        raise ModelError(f'Cannot reach {url}: {exc}') from exc
    except Exception:
        conn.close()
        raise


def json_request(url, path, body=None, timeout=15):
    conn, response = request(url, path, body, timeout)
    try:
        return json.loads(response.read())
    finally:
        conn.close()


def stream_json(url, path, body, job):
    conn, response = request(url, path, body, timeout=600, job=job)
    try:
        while not job.cancelled.is_set():
            line = response.readline()
            if not line:
                break
            line = line.strip()
            if not line or line.startswith(b':') or line.startswith(b'event:'):
                continue
            if line.startswith(b'data:'):
                line = line[5:].strip()
            if line == b'[DONE]':
                break
            part = json.loads(line)
            if part.get('error'):
                raise ModelError(str(part['error']))
            yield part
    except (OSError, http.client.HTTPException) as exc:
        if not job.cancelled.is_set():
            raise ModelError(f'The model stream was interrupted: {exc}') from exc
    finally:
        response.close()
        conn.close()
        with job.lock:
            job.connection = None
            job.socket = None
