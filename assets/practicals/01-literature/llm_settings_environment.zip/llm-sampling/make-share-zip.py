"""Create a small source distribution without models, settings, or environments."""
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parent
FILES = ('app.py', 'requirements.txt', 'Start LLM Sampling.cmd', 'README.md',
         'START HERE.txt', 'make-share-zip.py')
FOLDERS = ('sampling', 'web', 'tests')
SUFFIXES = {'.py', '.mjs', '.js', '.html', '.css', '.svg'}


def main():
    files = [ROOT / name for name in FILES]
    for folder in FOLDERS:
        files.extend(path for path in (ROOT / folder).rglob('*')
                     if path.is_file() and path.suffix in SUFFIXES
                     and '__pycache__' not in path.parts)
    for path in files:
        if not path.is_file() or not path.resolve().is_relative_to(ROOT):
            raise ValueError(f'Cannot package project file: {path.name}')
    destination = ROOT / 'dist' / 'llm-sampling-share.zip'
    destination.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path, (Path('llm-sampling') / path.relative_to(ROOT)).as_posix())
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('The sharing archive did not pass its integrity check.')
    print(f'Created {destination} ({destination.stat().st_size:,} bytes, {len(files)} files)')


if __name__ == '__main__':
    main()
